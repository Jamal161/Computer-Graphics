#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>
#define pi 3.14159265358979323846264
const double PI = 3.141592654;
int frameNumber = 0;


void drawDisk(double radius) {
	int d;
	glBegin(GL_POLYGON);
	for (d = 0; d < 32; d++) {
		double angle = 2*PI/32 * d;
		glVertex2d( radius*cos(angle), radius*sin(angle));
	}
	glEnd();
}

void init() {
	glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);

	glClearColor(0.5f, 0.5f, 1, 1);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, 7, -1, 4, -1, 1);
	glMatrixMode(GL_MODELVIEW);
}

void resize(int w, int h) {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (double)w / (double)h, 1.0, 100.0);
}

void drawSun() {
	int i;
	glColor3f(1,1,0);
	for (i = 0; i < 13; i++) {
		glRotatef( 360 / 13, 0, 0, 1 );
		glBegin(GL_LINES);
		glVertex2f(0, 0);
		glVertex2f(0.75f, 0);
		glEnd();
	}
	drawDisk(0.5);
	glColor3f(0,0,0);
}

void draw()
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glTranslatef(0.0f, 0.0f, -12.0f);



	glBegin(GL_QUADS);

    glColor3f(1,1,1);

    glVertex3f(-.20f, 1.20f, 0.0f); /// front child
	glVertex3f(.20f, 1.20f, 0.0f);
	glVertex3f(.20f, 1.00f, 0.0f);
    glVertex3f(-.20f, 1.00f, 0.0f);

    glVertex3f(.20f, 1.10f, 0.0f);
	glVertex3f(.10f, 1.10f, 0.0f);
	glVertex3f(.10f, -1.10f, 0.0f);
    glVertex3f(.20f, -1.10f, 0.0f);

    /// back child
  glVertex3f(-.20f, 1.10f, 0.0f);
	glVertex3f(-.10f, 1.10f, 0.0f);
	glVertex3f(-.10f, -1.10f, 0.0f);
    glVertex3f(-.20f, -1.10f, 0.0f);


    ///right big child
    glBegin(GL_QUADS);

    glColor3f(1,1,1);

    glVertex3f(1.20f, 1.20f, 0.0f); /// front child
	glVertex3f(1.60f, 1.20f, 0.0f);
	glVertex3f(1.60f, 1.00f, 0.0f);
    glVertex3f(1.20f, 1.00f, 0.0f);

   glVertex3f(1.20f, 1.10f, 0.0f);
	glVertex3f(1.30f, 1.10f, 0.0f);
	glVertex3f(1.30f, -1.10f, 0.0f);
    glVertex3f(1.20f, -1.10f, 0.0f);

    glVertex3f(1.60f, 1.10f, 0.0f);
	glVertex3f(1.50f, 1.10f, 0.0f);
	glVertex3f(1.50f, -1.10f, 0.0f);
    glVertex3f(1.60f, -1.10f, 0.0f);


    /// little child
    glBegin(GL_QUADS);

    glColor3f(1,1,1);

    glVertex3f(-.80f, .30f, 0.0f); /// front child
	glVertex3f(-.40f, .30f, 0.0f);
	glVertex3f(-.40f, .10f, 0.0f);
    glVertex3f(-.80f, .10f, 0.0f);

    glVertex3f(-.80f, .20f, 0.0f);
	glVertex3f(-.70f, .20f, 0.0f);
	glVertex3f(-.70f, -1.10f, 0.0f);
    glVertex3f(-.80f, -1.10f, 0.0f);

    glVertex3f(-.40f, .20f, 0.0f);
	glVertex3f(-.50f, .20f, 0.0f);
	glVertex3f(-.50f, -1.10f, 0.0f);
    glVertex3f(-.40f, -1.10f, 0.0f);


    ///stand

    glColor3f(0.0, 0.5, 0.0);

    glBegin(GL_QUADS);
        glVertex3f(-5.2, 4.0, 0.0);
        glVertex3f(-5.2, 2.0, 0.0);
        glVertex3f(-8.2, 2.0, 0.0);
        glVertex3f(-8.2, 4.0, 0.0);
    glEnd();


    glColor3f(0.45, 0.25, 0.13);

    glBegin(GL_QUADS);
        glVertex3f(-8.2, 4.0, 0.0);
        glVertex3f(-8.2, -4.0, 0.0);
        glVertex3f(-8.6, -4.0, 0.0);
        glVertex3f(-8.6, 4.0, 0.0);
    glEnd();


     /// little child right
    glBegin(GL_QUADS);

    glColor3f(1,1,1);

    glVertex3f(1.70f, .30f, 0.0f); /// front child
	glVertex3f(2.10f, .30f, 0.0f);
	glVertex3f(2.10f, .10f, 0.0f);
    glVertex3f(1.70f, .10f, 0.0f);

    glVertex3f(1.70f, .20f, 0.0f);
	glVertex3f(1.80f, .20f, 0.0f);
	glVertex3f(1.80f, -1.10f, 0.0f);
    glVertex3f(1.70f, -1.10f, 0.0f);

    glVertex3f(2.10f, .20f, 0.0f);
	glVertex3f(2.00f, .20f, 0.0f);
	glVertex3f(2.00f, -1.10f, 0.0f);
    glVertex3f(2.10f, -1.10f, 0.0f);

    ///Mother
    glBegin(GL_QUADS);

    glColor3f(1,1,1);


    glVertex3f(.35f, 1.20f, 0.0f);
	glVertex3f(.45f, 1.20f, 0.0f);
	glVertex3f(.45f, -1.20f, 0.0f);
    glVertex3f(.35f, -1.20f, 0.0f);

    glVertex3f(.75f, 1.20f, 0.0f);
	glVertex3f(.65f, 1.20f, 0.0f);
	glVertex3f(.65f, -1.20f, 0.0f);
    glVertex3f(.75f, -1.20f, 0.0f);


    glVertex3f(.35f, 1.20f, 0.0f);
	glVertex3f(.45f, 1.20f, 0.0f);
	glVertex3f(.45f, -1.20f, 0.0f);
    glVertex3f(.35f, -1.20f, 0.0f);

    glVertex3f(.75f, 1.20f, 0.0f);
	glVertex3f(.65f, 1.20f, 0.0f);
	glVertex3f(.65f, -1.20f, 0.0f);
    glVertex3f(.75f, -1.20f, 0.0f);

    ///chid side right


    glVertex3f(1.05f, 1.20f, 0.0f);
	glVertex3f(.95f, 1.20f, 0.0f);
	glVertex3f(.95f, -1.20f, 0.0f);
    glVertex3f(1.05f, -1.20f, 0.0f);


    ///top
    glVertex3f(.35f, 1.20f, 0.0f);
	glVertex3f(.45f, 1.20f, 0.0f);
	glVertex3f(.45f, 1.60f, 0.0f);
    glVertex3f(.35f, 1.60f, 0.0f);

    glVertex3f(.65f, 1.20f, 0.0f);
	glVertex3f(.75f, 1.20f, 0.0f);
	glVertex3f(.75f, 1.60f, 0.0f);
    glVertex3f(.65f, 1.60f, 0.0f);

    ///top top
    glVertex3f(.95f, 1.20f, 0.0f);
	glVertex3f(1.05f, 1.20f, 0.0f);
	glVertex3f(1.05f, 1.60f, 0.0f);
    glVertex3f(.95f, 1.60f, 0.0f);

    glVertex3f(.35f, 1.60f, 0.0f);
    glVertex3f(1.05f, 1.60f, 0.0f);
    glVertex3f(1.05f, 1.50f, 0.0f);
    glVertex3f(.35f, 1.50f, 0.0f);


    glEnd();
    glPushMatrix();
	glTranslated(5.8,3,0);
	glRotated(-frameNumber*0.7,0,0,1);
	drawSun();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-3 + 13*(frameNumber % 300) / 300.0, 0, 0);
	glScaled(0.3,0.3,1);
	glPopMatrix();

   glColor3f(.8,.188,.142);

    glBegin(GL_QUADS);


    glVertex3f(4.0f, -1.10f, 4.0f);
    glVertex3f(4.0f, -1.10f, -3.0f);
    glVertex3f(-3.0f, -1.10f, -3.0f);
    glVertex3f(-3.0f, -1.10f, 4.0f);


    glEnd();

    glColor3f(.0,.8,.0);

    glBegin(GL_QUADS);


    glVertex3f(20.0f, -1.11f, 20.0f);
    glVertex3f(20.0f, -1.11f, -20.0f);
    glVertex3f(-20.0f, -1.11f, -20.0f);
    glVertex3f(-20.0f, -1.11f, 20.0f);


    glEnd();

    ///Circle
    glColor3f(1,0,0);
    float ang=pi/2,b;
    b=pi/980;
    float x=0.0f,y=0.8f;
    float nx,ny,nz;
    float r;
    float hx=0.59,hy=0.0,hz=0;
    while( 1 )
    {
        if(ang>=2*pi+pi/2)break;
        ang+=b;
        r=sqrt(x*x+y*y);
        nx=r*cos(ang);
        ny=r*sin(ang);
        glBegin(GL_TRIANGLES);
        glVertex3f(hx, hy,1.6f);
        glVertex3f(x+hx, y+hy,1.6f);
        glVertex3f(nx+hx, ny+hy,1.7f);
        glEnd();

    }

    glColor3f(1,0,0);
    float ang0=pi/2,b0;
    b0=pi/980;
    float x0=0.0f,y0=0.5f;
    float nx0,ny0,nz0;
    float r0;
    float hx0=5.9,hy0=-2.6,hz0=0;
    while( 2 )
    {
        if(ang0>=2*pi+pi/1)break;
        ang0+=b0;
        r0=sqrt(x0*x0+y0*y0);
        nx0=r0*cos(ang0);
        ny0=r0*sin(ang0);

        glBegin(GL_TRIANGLES);
        glVertex3f(-hx0, -hy0,1.5f);
        glVertex3f(-x0-hx0, -y0-hy0,1.5f);
        glVertex3f(-nx0-hx0, -ny0-hy0,1.5f);
        glEnd();

    }

glutSwapBuffers();
}
void doFrame(int v) {
    frameNumber++;
    glutPostRedisplay();
    glutTimerFunc(30,doFrame,0);
}
int main(int argc, char** argv) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1300, 700);
    glutInitWindowPosition(100,100);
	glutCreateWindow("Shahid minar");
	init();
	glutDisplayFunc(draw);
	glutReshapeFunc(resize);
	glutTimerFunc(200,doFrame,0);
	glutMainLoop();
	return 0;
}

